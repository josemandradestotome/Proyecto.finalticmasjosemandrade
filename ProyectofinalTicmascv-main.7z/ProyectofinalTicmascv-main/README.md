
# Proyecto final del curso  (Ticmas Academy).

Este proyecto es una pagina web de un curriculum vitae que utiliza informacion personal de una persona random generada por la API "random user generator".

Enunciado del proyecto: Imaginate que sos un desarrollador recién incorporado en un nuevo emprendimiento tecnológico. En tu primera tarea en la empresa, te solicitan que realices una página web que posea un curriculum vitae. El CV comprende información personal, experiencia y habilidades.  La creación de este cv onlinte te permitirá llevar a la práctica todo lo que fuimos trabajando a lo largo de los módulos.

